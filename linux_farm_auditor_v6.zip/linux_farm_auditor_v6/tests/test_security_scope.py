import csv,json,subprocess,tempfile,unittest
from pathlib import Path
SCRIPT=Path(__file__).resolve().parents[1]/'correlate.py'
class ScopeTests(unittest.TestCase):
 def test_scope_mismatch_and_nan_cvss(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t); host=root/'server1';host.mkdir()
   (host/'packages.csv').write_text('package,installed_version,arch,manager\nexample,1.0,amd64,dpkg\n')
   (host/'os-release').write_text('ID=ubuntu\nVERSION_ID="24.04"\n')
   feed=root/'feed.json';feed.write_text(json.dumps([{'cve':'CVE-2025-12345','package':'example','manager':'dpkg','distro':'debian','distro_version':'12','fixed_version':'2.0','source':'vendor','severity':'HIGH','cvss':'NaN'}]))
   subprocess.run(['python3',str(SCRIPT),'--root',str(root),'--advisories',str(feed)],check=True,capture_output=True)
   with (root/'correlated_cves.csv').open() as f: row=list(csv.DictReader(f))[0]
   self.assertEqual(row['status'],'SCOPE_MISMATCH')
   self.assertEqual(row['cvss'],'')
 def test_missing_scope_unverified(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);host=root/'server1';host.mkdir()
   (host/'packages.csv').write_text('package,installed_version,arch,manager\nexample,1.0,amd64,dpkg\n')
   feed=root/'feed.json';feed.write_text(json.dumps([{'cve':'CVE-2025-12345','package':'example','manager':'dpkg','distro':'ubuntu','fixed_version':'2.0','source':'vendor'}]))
   subprocess.run(['python3',str(SCRIPT),'--root',str(root),'--advisories',str(feed)],check=True,capture_output=True)
   with (root/'correlated_cves.csv').open() as f: row=list(csv.DictReader(f))[0]
   self.assertEqual(row['status'],'UNVERIFIED_SCOPE')
if __name__=='__main__':unittest.main()
