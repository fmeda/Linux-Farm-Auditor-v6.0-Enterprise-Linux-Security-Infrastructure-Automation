import csv,json,subprocess,tempfile,unittest
from pathlib import Path
SCRIPT=Path(__file__).resolve().parents[1]/'consolidate.py'
class Tests(unittest.TestCase):
 def test_unreachable_and_cve_severity_and_escaping(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t); root=d/'run';(root/'srv1').mkdir(parents=True)
   (d/'inventory.ini').write_text('[linux_farm]\nsrv1\nsrv2\n')
   (root/'srv1'/'execution.json').write_text('{"status":"COMPLETED","rc":0}')
   (root/'srv1'/'security_checks.csv').write_text('host,check,status,detail\nsrv1,SSH,WARN,<script>alert(1)</script>\n')
   (d/'cves.json').write_text(json.dumps([{'host':'srv1','cve':'CVE-2025-12345','severity':'CRITICAL','cvss':9.8,'source':'test'},{'host':'srv2','cve':'CVE-2025-22222','severity':'HIGH','cvss':7.5},{'host':'srv1','cve':'invalid','severity':'HIGH'}]))
   subprocess.run(['python3',str(SCRIPT),'--root',str(root),'--inventory',str(d/'inventory.ini'),'--advisories',str(d/'cves.json'),'--ansible-rc','2'],check=True,capture_output=True)
   m=json.loads((root/'manifest.json').read_text())
   self.assertEqual(m['cve_by_severity']['CRITICAL'],1)
   self.assertEqual(m['cve_by_severity']['HIGH'],1)
   self.assertEqual(m['host_statuses']['UNREACHABLE_OR_UNREPORTED'],1)
   self.assertEqual(m['security_warnings'],1)
   self.assertNotIn('<script>',(root/'index.html').read_text())
   self.assertIn('&lt;script&gt;', (root/'index.html').read_text())
 def test_no_advisories_not_assessed(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);(d/'inv').write_text('[linux_farm]\nnode1\n')
   subprocess.run(['python3',str(SCRIPT),'--root',str(d/'reports'),'--inventory',str(d/'inv')],check=True,capture_output=True)
   m=json.loads((d/'reports'/'manifest.json').read_text())
   self.assertEqual(m['cve_coverage'],'NOT_ASSESSED')
   self.assertEqual(m['host_statuses']['UNREACHABLE_OR_UNREPORTED'],1)
if __name__=='__main__':unittest.main()
