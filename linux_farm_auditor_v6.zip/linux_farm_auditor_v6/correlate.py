#!/usr/bin/env python3
"""Controller-only advisory correlation. No version string lexicographic comparisons."""
import argparse,csv,json,re,subprocess,shutil,math
from pathlib import Path
from collections import Counter
P=argparse.ArgumentParser();P.add_argument('--root',required=True);P.add_argument('--advisories',required=True);P.add_argument('--kev');P.add_argument('--epss');a=P.parse_args()
root=Path(a.root)
def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
feed=read_json(a.advisories)
if not isinstance(feed,list):raise SystemExit('Advisories must be JSON list')
kev=set()
if a.kev:
 k=read_json(a.kev)
 for v in k.get('vulnerabilities',[]) if isinstance(k,dict) else []:
  if isinstance(v,dict):kev.add(str(v.get('cveID','')).upper())
epss={}
if a.epss:
 with open(a.epss,newline='') as f:
  for r in csv.DictReader(f):
   try:
    value=float(r['epss'])
    if math.isfinite(value) and 0 <= value <= 1: epss[r['cve'].upper()]=value
   except (KeyError,TypeError,ValueError):pass

def compare(manager,installed,fixed):
 if manager=='dpkg' and shutil.which('dpkg'):
  try:
   p=subprocess.run(['dpkg','--compare-versions',installed,'lt',fixed],timeout=3)
   q=subprocess.run(['dpkg','--compare-versions',installed,'ge',fixed],timeout=3)
   return 'POTENTIALLY_AFFECTED' if p.returncode==0 else 'FIXED_OR_NEWER' if q.returncode==0 else 'UNKNOWN'
  except (OSError,subprocess.TimeoutExpired):pass
 if manager=='rpm' and shutil.which('rpmdev-vercmp'):
  try:
   p=subprocess.run(['rpmdev-vercmp',installed,fixed],capture_output=True,text=True,timeout=3)
   if p.returncode in (0,11,12):
    output=p.stdout.lower()
    if ' < ' in output:return 'POTENTIALLY_AFFECTED'
    if ' > ' in output or ' = ' in output:return 'FIXED_OR_NEWER'
  except (OSError,subprocess.TimeoutExpired):pass
 return 'UNKNOWN_COMPARATOR'

def os_release(path):
 result={}
 if not path.is_file():return result
 for line in path.read_text(encoding='utf-8').splitlines():
  if '=' in line and not line.startswith('#'):
   k,v=line.split('=',1)
   if k in ('ID','VERSION_ID'):result[k]=v.strip().strip('"').strip("'")
 return result

def valid_cvss(score):
 try:
  value=float(score)
  return value if math.isfinite(value) and 0 <= value <= 10 else ''
 except (TypeError,ValueError):return ''

rows=[];coverage={}
for folder in sorted(root.iterdir()):
 if not folder.is_dir():continue
 inventory=folder/'packages.csv'
 if not inventory.exists():coverage[folder.name]='NO_PACKAGE_INVENTORY';continue
 with inventory.open(newline='') as f: packages=list(csv.DictReader(f))
 coverage[folder.name]='INVENTORIED' if packages else 'EMPTY_INVENTORY'
 osinfo=os_release(folder/'os-release')
 lookup={(p['package'],p['manager']):p for p in packages}
 for advisory in feed:
  if not isinstance(advisory,dict):continue
  cve=str(advisory.get('cve','')).upper()
  if not re.fullmatch(r'CVE-\d{4}-\d{4,}',cve):continue
  if advisory.get('host') not in (None,'',folder.name):continue
  package=str(advisory.get('package',''));manager=str(advisory.get('manager',''))
  p=lookup.get((package,manager))
  if not p:continue
  distro=str(advisory.get('distro',''))
  # Vendor feeds MUST be explicitly scoped to distro/version and sourced; otherwise do not infer applicability.
  if not distro or not advisory.get('source') or not advisory.get('distro_version'):
   status='UNVERIFIED_SCOPE'
  elif not osinfo or distro.lower()!=osinfo.get('ID','').lower() or str(advisory['distro_version'])!=osinfo.get('VERSION_ID'):
   status='SCOPE_MISMATCH'
  elif not advisory.get('fixed_version'):
   status='UNKNOWN_FIXED_VERSION'
  else:status=compare(manager,p['installed_version'],str(advisory['fixed_version']))
  severity=str(advisory.get('severity','UNKNOWN')).upper()
  if severity not in ('CRITICAL','HIGH','MEDIUM','LOW','NONE','UNKNOWN'):severity='UNKNOWN'
  score=valid_cvss(advisory.get('cvss',''))
  rows.append(dict(host=folder.name,cve=cve,package=package,installed_version=p['installed_version'],fixed_version=advisory.get('fixed_version',''),manager=manager,distro=distro,severity=severity,cvss=score,source=advisory.get('source',''),status=status,kev='YES' if cve in kev else 'NO_DATA' if not a.kev else 'NO',epss=epss.get(cve,''),priority='P1' if status=='POTENTIALLY_AFFECTED' and (cve in kev or severity=='CRITICAL') else 'P2' if status=='POTENTIALLY_AFFECTED' and severity=='HIGH' else 'REVIEW'))
fields=['host','cve','package','installed_version','fixed_version','manager','distro','severity','cvss','source','status','kev','epss','priority']
with (root/'correlated_cves.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
(root/'correlation_summary.json').write_text(json.dumps({'coverage':coverage,'status_counts':dict(Counter(r['status'] for r in rows)),'warning':'Advisory distro and version must exactly match /etc/os-release. Matching installed package and comparing vendor fixed version is not proof of vulnerability. Distro applicability and backports must be validated; rpm comparison requires rpmdev-vercmp on controller. KEV and EPSS are snapshot inputs, not live feeds.'},indent=2)+'\n')
# Append escaped correlation table to existing HTML report, if present.
import html
page=root/'index.html'
if page.exists():
 content=page.read_text(encoding='utf-8')
 cols=['host','cve','package','severity','status','kev','epss','priority','source']
 table='<h2>Package / Vendor CVE Correlation (triage only)</h2><p>Requires vendor-scoped advisory verification. Missing rows do not mean zero CVEs.</p><table><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in cols)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(k,'')))+'</td>' for k in cols)+'</tr>' for r in rows)+'</tbody></table>'
 content=content.replace('</html>',table+'</html>')
 page.write_text(content,encoding='utf-8')
print('Correlated rows:',len(rows))
