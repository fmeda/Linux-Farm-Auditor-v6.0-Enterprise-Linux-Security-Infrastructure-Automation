#!/usr/bin/env python3
"""Normalize passive security checks and optional trusted vendor CVE findings."""
import argparse,csv,json,re,pathlib,html
p=argparse.ArgumentParser();p.add_argument('--reports',required=True);p.add_argument('--advisories',default='');a=p.parse_args()
root=pathlib.Path(a.reports); hosts=root/'hosts'; records=[]; cves=[]
for f in sorted(hosts.glob('*.txt')):
    for line in f.read_text(errors='replace').splitlines():
        if line.startswith('SECURITY_CHECK|'):
            parts=line.split('|',3)
            if len(parts)==4: records.append(dict(host=f.stem,check=parts[1],status=parts[2],detail=parts[3]))
if a.advisories:
    data=json.loads(pathlib.Path(a.advisories).read_text())
    if not isinstance(data,list): raise ValueError('Advisories must be JSON list')
    for x in data:
        if not isinstance(x,dict): continue
        cve=str(x.get('cve','')).upper(); severity=str(x.get('severity','UNKNOWN')).upper()
        if not re.fullmatch(r'CVE-\d{4}-\d{4,}',cve): continue
        if severity not in ('CRITICAL','HIGH','MEDIUM','LOW','UNKNOWN'): severity='UNKNOWN'
        score=x.get('cvss','')
        if score!='':
            try:
                score=float(score)
                if not 0<=score<=10: score=''
            except (TypeError,ValueError): score=''
        cves.append(dict(host=str(x.get('host','')),cve=cve,severity=severity,cvss=score,package=str(x.get('package','')),fixed_version=str(x.get('fixed_version','')),source=str(x.get('source','')),status=str(x.get('status','UNVERIFIED'))))
for name,rows,cols in [('security_checks.csv',records,['host','check','status','detail']),('cve_findings.csv',cves,['host','cve','severity','cvss','package','fixed_version','source','status'])]:
    with (root/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
counts={k:sum(x['severity']==k for x in cves) for k in ('CRITICAL','HIGH','MEDIUM','LOW','UNKNOWN')}
summary={'security_checks':len(records),'warnings':sum(x['status']=='WARN' for x in records),'cve_findings_imported':len(cves),'by_severity':counts,'cve_coverage':'IMPORTED_ONLY' if a.advisories else 'NOT_ASSESSED','notice':'Imported findings are not independently validated; vendor applicability and installed versions must be checked.'}
(root/'security_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Security checks:',len(records),'CVE findings imported:',len(cves),'CVE coverage:',summary['cve_coverage'])
