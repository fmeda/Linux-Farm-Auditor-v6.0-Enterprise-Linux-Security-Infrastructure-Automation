# Linux Farm Auditor v4.0 — Ansible Controller Collection

## Architecture
Only the controller requires access to the mounted NFS/SMB share. Each managed server receives temporary auditor scripts over SSH; results are fetched to the controller share. Cleanup is attempted even after failed tasks. The controller consolidates all host evidence into HTML, CSV and JSON.

## Prerequisites
Linux controller with Bash, Python 3, Ansible (`ansible-playbook`), SSH access to managed hosts, and a **mounted and writable** NFS/SMB path. Target servers require Bash, Python 3 for structured security reporting, and common Linux utilities. Configure SSH host-key verification and least-privilege credentials. For deeper checks use an approved privileged audit account.

## Usage
```bash
chmod +x run.sh linux_auditor.sh
./run.sh /mnt/audit-share inventory.ini
./run.sh /mnt/audit-share inventory.ini verified_vendor_findings.json
```

## CVE JSON schema
```json
[{"host":"server01","cve":"CVE-2025-12345","severity":"HIGH","cvss":8.1,"package":"example-package","fixed_version":"1.2.3","source":"vendor advisory URL or ID","status":"UNVERIFIED"}]
```
The JSON is **sample input**, not proof of applicability. Use authenticated vendor advisories/scanners and validate package versions, backports and installed software. Severity grouping uses the supplied vendor severity. No active exploitation tests are performed. Missing CVE data = `NOT_ASSESSED`.

## Reports
`<share>/<run-id>/index.html`, `farm_summary.csv`, `farm_security.csv`, `farm_cves.csv`, `manifest.json`, `ansible.log`, plus `<host>/...` evidence.

## Failure handling
Individual reachable hosts use `block/rescue/always` for error reporting and cleanup. Unreachable hosts cannot run rescue, so the controller report identifies them as `UNREACHABLE_OR_UNREPORTED`. Ansible may exit nonzero while the consolidated report is still generated. Network-share outage during the run can prevent report writing; use monitoring, backups and a retry procedure. Remote cleanup is best-effort and may not run after a sudden SSH failure.

## Limitations
The controller refuses to start unless the destination is a mountpoint. A mount may still fail mid-run. `ansible.log` may include sensitive diagnostic data; restrict access and retention. Inventory parser supports standard `[linux_farm]` INI entries (not dynamic/YAML inventory for missing-host detection). Never claim the audit proves all vulnerabilities are absent.


## v5.0: Controller-side CVE correlation
The controller collects `packages.csv` from each server (read-only RPM or dpkg inventory). When a curated vendor advisory JSON is supplied, it produces `correlated_cves.csv` and `correlation_summary.json`. Optional offline CISA KEV JSON and FIRST EPSS CSV snapshots enrich prioritization. No network downloads occur automatically, so provenance and snapshot freshness must be verified by the operator.

```bash
./run.sh /mnt/audit-share inventory.ini advisories.vendor.json kev.json epss.csv
```

Advisory records must contain `distro`, `manager`, `package`, `cve`, `fixed_version`, `severity`, and `source`. A host-specific record may include `host`. **Distro is a mandatory scope label, but automatic OS matching is NOT implemented**: operators must supply vendor-scoped feeds appropriate to the inventory. On the controller, Debian version comparison requires `dpkg`; RPM comparison requires `rpmdev-vercmp`. Missing comparators return UNKNOWN_COMPARATOR, never a fabricated vulnerability. The result `POTENTIALLY_AFFECTED` is a triage indicator, not proof of exploitation. RPM vendor backports, epochs, module streams, and package variants require independent validation. Example advisory data is synthetic.

`correlated_cves.csv` is separate from the legacy `farm_cves.csv`; HTML includes a separately labeled correlation table when advisories are supplied. Avoid using fabricated test feeds in production.


## v6 security engineering changes
See `SECURITY.md` for NIST CSF 2.0, CIS Controls v8, NIST 800-53, OWASP and supply-chain mappings (not compliance certifications). Controller entrypoint resolves its own directory, validates feed files, uses umask 077 and preserves consolidation/correlation failure codes. Remote OS evidence is collected and vendor advisories must match `ID` and `VERSION_ID` exactly; mismatches are not assessed as affected. Invalid CVSS/EPSS non-finite values are rejected.

Run regression tests: `python3 -m unittest discover -s tests -v`. Syntax: `bash -n run.sh linux_auditor.sh`. Ansible integration requires real SSH, ansible-playbook and a mounted share; it is not covered by unit tests.
