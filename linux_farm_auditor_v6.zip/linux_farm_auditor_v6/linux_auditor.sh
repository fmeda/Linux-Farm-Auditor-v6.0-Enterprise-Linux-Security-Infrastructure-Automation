#!/usr/bin/env bash
set -uo pipefail
export LC_ALL=C
VERSION=2.0
TARGETS=""; OUT="./linux_audit_$(date +%Y%m%d_%H%M%S)"; SSH_USER="${USER}"; PORT=22; TIMEOUT=8; LIMIT=4; MODE=local
ADVISORIES=""
usage(){ cat <<HELP
Linux Server & Farm Health Auditor v${VERSION} (read-only)
Usage: $0 [--local | --inventory hosts.txt] [--user USER] [--port 22] [--timeout 8] [--jobs 4] [--output DIR] [--advisories vendor_findings.json]
Inventory: one hostname or IP per line; blank lines and # comments ignored.
SSH: BatchMode, strict host key checking, existing SSH agent/key. No passwords stored.
Exit: 0 all hosts audited, 1 host checks flagged, 2 unreachable/collection errors.
HELP
}
while (($#)); do
 case "$1" in
 --local) MODE=local; shift;;
 --advisories) (($#>=2)) || exit 2; ADVISORIES=$2; shift 2;;
 --inventory) (($#>=2)) || { usage; exit 2; }; MODE=farm; TARGETS=$2; shift 2;;
 --user) SSH_USER=$2; shift 2;;
 --port) PORT=$2; shift 2;;
 --timeout) TIMEOUT=$2; shift 2;;
 --jobs) LIMIT=$2; shift 2;;
 --output) OUT=$2; shift 2;;
 -h|--help) usage; exit 0;;
 *) echo "Unknown option: $1" >&2; usage; exit 2;;
 esac
done
[[ $PORT =~ ^[0-9]+$ && $TIMEOUT =~ ^[0-9]+$ && $LIMIT =~ ^[0-9]+$ ]] || { echo 'Invalid numeric argument' >&2; exit 2; }
((PORT>=1 && PORT<=65535 && TIMEOUT>=1 && LIMIT>=1 && LIMIT<=32)) || exit 2
[[ $SSH_USER =~ ^[a-zA-Z_][a-zA-Z0-9_.-]*$ ]] || { echo 'Invalid SSH user' >&2; exit 2; }
[[ $MODE != farm || -r $TARGETS ]] || { echo 'Inventory not readable' >&2; exit 2; }
mkdir -p "$OUT/hosts" || exit 2
OUT=$(cd "$OUT" && pwd)
cat > "$OUT/collector.sh" <<'COLLECT'
#!/usr/bin/env bash
set -u
export LC_ALL=C
section(){ printf '\n===== %s =====\n' "$1"; }
run(){ local label=$1; shift; section "$label"; if command -v "$1" >/dev/null 2>&1; then timeout 12 "$@" 2>&1 || echo '[WARN] Command unavailable, denied, or timed out'; else echo '[INFO] Tool not installed'; fi; }
section 'IDENTITY'; date -u '+UTC %Y-%m-%dT%H:%M:%SZ'; hostname -f 2>/dev/null || hostname; uname -a; cat /etc/os-release 2>/dev/null | head -n 8; uptime
run 'CPU' lscpu
run 'LOAD' uptime
run 'MEMORY' free -h
run 'VMSTAT' vmstat 1 2
run 'TOP CPU' ps -eo pid,comm,%cpu,%mem --sort=-%cpu
run 'FILESYSTEM' df -hPT
run 'INODES' df -iPT
run 'BLOCK DEVICES' lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,ROTA
run 'MOUNTS' findmnt -r
run 'RAID' cat /proc/mdstat
run 'IP ADDRESSES' ip -brief address
run 'LINK STATS' ip -s link
run 'ROUTES' ip route show
section 'DNS CONFIG'; if [[ -r /etc/resolv.conf ]]; then sed -E 's/^(search|domain).*/\1 [redacted]/; s/^(nameserver).*/\1 [configured]/' /etc/resolv.conf; fi
run 'SOCKETS' ss -tuln
run 'FAILED SERVICES' systemctl --failed --no-pager --plain
run 'RUNNING SERVICES' systemctl list-units --type=service --state=running --no-pager --plain
run 'TIMERS' systemctl list-timers --all --no-pager --plain
run 'SECURITY SELINUX' getenforce
run 'SECURITY APPARMOR' aa-status
run 'FIREWALL FIREWALLD' firewall-cmd --state
run 'FIREWALL UFW' ufw status
run 'SSH CONFIG EFFECTIVE' sshd -T
run 'LOG ERRORS' journalctl -p err -n 80 --no-pager -o short-iso
run 'KERNEL ERRORS' journalctl -k -p err -n 60 --no-pager
run 'DISK IOSTAT' iostat -xz 1 2
section 'PRESSURE'; for f in /proc/pressure/{cpu,memory,io}; do [[ -r $f ]] && { echo "$f"; cat "$f"; }; done
section 'PACKAGE MANAGER'; for p in apt-get dnf yum zypper; do command -v "$p" >/dev/null 2>&1 && echo "$p available"; done
section 'SECURITY SUMMARY'; if command -v getent >/dev/null; then getent passwd | awk -F: '$3==0 {print "UID0 account: " $1}'; fi
section 'SECURITY TESTS READ ONLY'
security_check(){ local id="$1" result="$2" detail="$3"; printf 'SECURITY_CHECK|%s|%s|%s\n' "$id" "$result" "$detail"; }
if command -v sshd >/dev/null 2>&1; then
 sshcfg=$(timeout 8 sshd -T 2>/dev/null || true)
 if [[ -z "$sshcfg" ]]; then security_check SSH_EFFECTIVE UNKNOWN 'sshd -T unavailable or needs privilege'; else
 for rule in 'permitrootlogin no' 'permitemptypasswords no' 'passwordauthentication no' 'x11forwarding no'; do
 key=${rule%% *}; val=${rule#* }; actual=$(awk -v k="$key" '$1==k {print $2;exit}' <<< "$sshcfg")
 if [[ -z "$actual" ]]; then security_check "SSH_$key" UNKNOWN 'effective value absent'; elif [[ "$actual" == "$val" ]]; then security_check "SSH_$key" PASS "$actual"; else security_check "SSH_$key" WARN "actual=$actual expected=$val (review policy)"; fi
 done
 fi
else security_check SSH_EFFECTIVE UNKNOWN 'sshd unavailable'; fi
for pair in 'net.ipv4.conf.all.accept_redirects=0' 'net.ipv4.conf.default.accept_redirects=0' 'net.ipv4.conf.all.send_redirects=0' 'net.ipv4.conf.all.rp_filter=1' 'kernel.randomize_va_space=2'; do
 key=${pair%%=*}; expected=${pair#*=}; actual=$(sysctl -n "$key" 2>/dev/null || true)
 if [[ -z "$actual" ]]; then security_check "SYSCTL_$key" UNKNOWN 'unavailable'; elif [[ "$actual" == "$expected" ]]; then security_check "SYSCTL_$key" PASS "$actual"; else security_check "SYSCTL_$key" WARN "actual=$actual expected=$expected (review topology)"; fi
done
for f in /etc/passwd /etc/shadow /etc/sudoers /etc/ssh/sshd_config; do
 if [[ -e "$f" ]]; then
 mode=$(stat -c %a "$f" 2>/dev/null || true)
 owner=$(stat -c %u "$f" 2>/dev/null || true)
 if [[ -z "$mode" || -z "$owner" ]]; then security_check "FILE_$f" UNKNOWN 'stat denied';
 elif [[ "$owner" != 0 ]]; then security_check "FILE_$f" WARN "owner_uid=$owner mode=$mode";
 elif [[ "$f" == /etc/shadow ]] && (( (8#$mode & 0007) != 0 )); then security_check "FILE_$f" WARN "mode=$mode others permissions present";
 else security_check "FILE_$f" PASS "owner_uid=$owner mode=$mode"; fi
 else security_check "FILE_$f" UNKNOWN 'not present'; fi
done
if command -v systemctl >/dev/null 2>&1; then
 for svc in auditd chronyd systemd-timesyncd; do
  state=$(systemctl is-active "$svc" 2>/dev/null || true)
  security_check "SERVICE_$svc" INFO "state=${state:-unknown}"
 done
fi
if command -v getenforce >/dev/null 2>&1; then security_check SELINUX INFO "$(getenforce 2>/dev/null)"; fi
if command -v aa-status >/dev/null 2>&1; then security_check APPARMOR INFO "$(aa-status --enabled >/dev/null 2>&1 && echo enabled || echo unknown-or-disabled)"; fi
section 'VENDOR SECURITY ADVISORIES (CACHE ONLY)'
if command -v dnf >/dev/null 2>&1; then
 timeout 20 dnf -q --cacheonly updateinfo list --security available 2>&1 || echo '[INFO] DNF cached advisory query unavailable; not proof of no CVEs'
elif command -v yum >/dev/null 2>&1; then
 timeout 20 yum -q --cacheonly updateinfo list security 2>&1 || echo '[INFO] YUM cached advisory query unavailable; not proof of no CVEs'
elif command -v apt-get >/dev/null 2>&1; then
 echo '[INFO] Debian/Ubuntu: no reliable CVE enumeration from apt cache alone; use vendor OVAL/USN/DSA or authenticated scanner.'
else echo '[INFO] Vendor advisory integration unavailable'; fi

section 'AUTOMATED METRICS'
awk '/MemTotal:/{t=$2}/MemAvailable:/{a=$2}END{if(t>0)printf "METRIC memory_used_pct %.1f\n",100*(t-a)/t}' /proc/meminfo
awk '{printf "METRIC load1 %.2f\n",$1}' /proc/loadavg
awk '/^cpu[0-9]+ /{n++}END{if(n>0)printf "METRIC cpu_count %d\n",n}' /proc/stat
df -P -x tmpfs -x devtmpfs 2>/dev/null | awk 'NR>1 && $5~/^[0-9]+%$/ {gsub(/%/,"",$5); if($5>max)max=$5} END{printf "METRIC disk_max_pct %d\n",max+0}'
df -Pi -x tmpfs -x devtmpfs 2>/dev/null | awk 'NR>1 && $5~/^[0-9]+%$/ {gsub(/%/,"",$5); if($5>max)max=$5} END{printf "METRIC inode_max_pct %d\n",max+0}'
COLLECT
chmod 700 "$OUT/collector.sh"
printf 'host,status,memory_used_pct,disk_max_pct,inode_max_pct,load1,cpu_count,alerts\n' > "$OUT/summary.csv"
check_host(){
 local host=$1 safe=$2 rc status=OK alerts=0 mem disk inode load cpus
 local file="$OUT/hosts/$safe.txt" err="$OUT/hosts/$safe.stderr"
 if [[ $MODE == local ]]; then bash "$OUT/collector.sh" > "$file" 2> "$err"; rc=$?; else
 ssh -T -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout="$TIMEOUT" -o ConnectionAttempts=1 -p "$PORT" "${SSH_USER}@${host}" 'bash -s' < "$OUT/collector.sh" > "$file" 2> "$err"; rc=$?; fi
 if ((rc!=0)); then status=UNREACHABLE; alerts=1; else
 mem=$(awk '$1=="METRIC"&&$2=="memory_used_pct"{print $3}' "$file" | tail -1)
 disk=$(awk '$1=="METRIC"&&$2=="disk_max_pct"{print $3}' "$file" | tail -1)
 inode=$(awk '$1=="METRIC"&&$2=="inode_max_pct"{print $3}' "$file" | tail -1)
 load=$(awk '$1=="METRIC"&&$2=="load1"{print $3}' "$file" | tail -1)
 cpus=$(awk '$1=="METRIC"&&$2=="cpu_count"{print $3}' "$file" | tail -1)
 if [[ -z $mem || -z $disk || -z $inode || -z $load || -z $cpus ]]; then status=INCOMPLETE; alerts=1
 elif awk -v m="$mem" -v d="$disk" -v i="$inode" -v l="$load" -v c="$cpus" 'BEGIN{exit !(m>=90 || d>=90 || i>=90 || (c>0 && l/c>=2))}'; then status=WARN; alerts=1; fi
 fi
 printf '%s,%s,%s,%s,%s,%s,%s,%s\n' "$host" "$status" "${mem:-}" "${disk:-}" "${inode:-}" "${load:-}" "${cpus:-}" "$alerts" > "$OUT/hosts/$safe.csv"
}
export -f check_host
export OUT MODE SSH_USER PORT TIMEOUT
if [[ $MODE == local ]]; then check_host localhost localhost
else
 declare -a hosts=(); declare -A seen=();
 while IFS= read -r host || [[ -n $host ]]; do
 host=${host%%#*}; host=${host//$'\r'/}; host=${host//[[:space:]]/}; [[ -z $host ]] && continue
 [[ $host =~ ^[a-zA-Z0-9][a-zA-Z0-9._:-]*$ ]] || { echo "Invalid host: $host" >&2; exit 2; }
 [[ -n ${seen[$host]+x} ]] && continue; seen[$host]=1; hosts+=("$host")
 done < "$TARGETS"
 ((${#hosts[@]})) || { echo 'Empty inventory' >&2; exit 2; }
 for host in "${hosts[@]}"; do
 safe=$(printf '%s' "$host" | tr ':.' '__'); check_host "$host" "$safe" &
 while (( $(jobs -rp | wc -l) >= LIMIT )); do wait -n || :; done
 done
 wait || :
fi
find "$OUT/hosts" -name '*.csv' -type f -print0 | sort -z | xargs -0 -r cat >> "$OUT/summary.csv"
python3 - "$OUT" <<'PY' 2>/dev/null || :
import csv,html,sys,pathlib
p=pathlib.Path(sys.argv[1]); rows=list(csv.DictReader((p/'summary.csv').open()))
headers=list(rows[0]) if rows else []
table=''.join('<tr>'+''.join('<td>'+html.escape(str(row.get(k,'')))+'</td>' for k in headers)+'</tr>' for row in rows)
(p/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Linux Audit</title><style>body{font:15px sans-serif;margin:3em;background:#101827;color:#eee}table{border-collapse:collapse}td,th{padding:10px;border:1px solid #526071}th{background:#22344d}</style><h1>Linux Server & Farm Auditor</h1><p>Read-only assessment. WARN thresholds: memory/disk/inodes ≥90%, load1/vCPU ≥2.</p><table><tr>'+''.join('<th>'+html.escape(k)+'</th>' for k in headers)+'</tr>'+table+'</table>',encoding='utf-8')
PY
if command -v python3 >/dev/null 2>&1; then
 python3 "$(dirname "$0")/security_report.py" --reports "$OUT" --advisories "${ADVISORIES:-}" || echo '[WARN] Security report generation failed' >&2
fi
printf 'Reports: %s\n' "$OUT"
awk -F, 'NR>1{print $1 ": " $2; if($2=="UNREACHABLE"||$2=="INCOMPLETE")bad=2;else if($2=="WARN"&&bad<1)bad=1}END{exit bad}' "$OUT/summary.csv"
