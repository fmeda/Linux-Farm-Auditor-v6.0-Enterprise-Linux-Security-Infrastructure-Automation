#!/usr/bin/env python3
"""Consolidate controller-collected evidence. Imported CVEs are not independently verified."""
import argparse,csv,html,json,re,configparser
from pathlib import Path
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--inventory',required=True);p.add_argument('--advisories');p.add_argument('--ansible-rc',type=int,default=0);a=p.parse_args()
root=Path(a.root);root.mkdir(parents=True,exist_ok=True)
inv=Path(a.inventory).read_text()
hosts=[]; in_group=False
for line in inv.splitlines():
    line=line.strip()
    if line.startswith('['): in_group=(line=='[linux_farm]');continue
    if in_group and line and not line.startswith(('#',';')):
        host=line.split()[0]
        if re.fullmatch(r'[A-Za-z0-9_.-]+',host) and host not in hosts:hosts.append(host)
# Also include completed hosts not present in parsed INI inventory.
hosts=sorted(set(hosts)|{d.name for d in root.iterdir() if d.is_dir() and re.fullmatch(r'[A-Za-z0-9_.-]+',d.name)})
rows=[]; checks=[]; cves=[]
for host in hosts:
    folder=root/host; meta=folder/'execution.json'
    try: execution=json.loads(meta.read_text()) if meta.exists() else {'status':'UNREACHABLE_OR_UNREPORTED'}
    except (ValueError,OSError): execution={'status':'INVALID_METADATA'}
    status=execution.get('status','UNKNOWN');summ=folder/'summary.csv'
    if summ.exists():
        try:
            with summ.open(newline='') as f:
                for r in csv.DictReader(f): rows.append({'host':host,'status':status,**{k:str(v) for k,v in r.items()}})
        except (OSError,csv.Error):status='INVALID_SUMMARY'
    if not any(r['host']==host for r in rows):rows.append({'host':host,'status':status})
    sec=folder/'security_checks.csv'
    if sec.exists():
        try:
            with sec.open(newline='') as f:
                for r in csv.DictReader(f):checks.append({'host':host,**{k:v for k,v in r.items() if k!='host'}})
        except (OSError,csv.Error):pass
if a.advisories:
    data=json.loads(Path(a.advisories).read_text())
    if not isinstance(data,list):raise SystemExit('Advisories must be a JSON list')
    for finding in data:
        if not isinstance(finding,dict):continue
        host=str(finding.get('host',''))
        cve=str(finding.get('cve','')).upper();severity=str(finding.get('severity','UNKNOWN')).upper()
        if host not in hosts or not re.fullmatch(r'CVE-\d{4}-\d{4,}',cve):continue
        if severity not in ('CRITICAL','HIGH','MEDIUM','LOW','NONE','UNKNOWN'):severity='UNKNOWN'
        cvss=finding.get('cvss','')
        try:
            if cvss!='' and not (0<=float(cvss)<=10):cvss=''
        except (TypeError,ValueError):cvss=''
        cves.append({'host':host,'cve':cve,'severity':severity,'cvss':cvss,'package':str(finding.get('package','')),'fixed_version':str(finding.get('fixed_version','')),'source':str(finding.get('source','')),'status':str(finding.get('status','UNVERIFIED'))})
# Keep per-host vendor findings if produced by collector, without treating them as verified.
for host in hosts:
    path=root/host/'cve_findings.csv'
    if path.exists():
        try:
            with path.open(newline='') as f:
                for r in csv.DictReader(f):
                    cve=str(r.get('cve','')).upper()
                    if re.fullmatch(r'CVE-\d{4}-\d{4,}',cve):
                        severity=str(r.get('severity','UNKNOWN')).upper()
                        if severity not in ('CRITICAL','HIGH','MEDIUM','LOW','NONE','UNKNOWN'):severity='UNKNOWN'
                        cves.append({'host':host,'cve':cve,'severity':severity,'cvss':r.get('cvss',''),'package':r.get('package',''),'fixed_version':r.get('fixed_version',''),'source':r.get('source',''),'status':r.get('status','UNVERIFIED')})
        except (OSError,csv.Error):pass
cves=list({(r['host'],r['cve'],r['package'],r['source']):r for r in cves}.values())
def writecsv(name,data,fields):
    with (root/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(data)
writecsv('farm_summary.csv',rows,sorted(set().union(*(r.keys() for r in rows)) if rows else {'host','status'}))
writecsv('farm_security.csv',checks,['host','check','status','detail'])
writecsv('farm_cves.csv',cves,['host','cve','severity','cvss','package','fixed_version','source','status'])
counts=Counter(r['severity'] for r in cves);states=Counter(r['status'] for r in rows)
manifest={'hosts':hosts,'hosts_reported':sum((root/h/'execution.json').exists() for h in hosts),'host_statuses':dict(states),'ansible_rc':a.ansible_rc,'cve_coverage':'IMPORTED_ONLY' if cves or a.advisories else 'NOT_ASSESSED','cve_by_severity':{s:counts[s] for s in ['CRITICAL','HIGH','MEDIUM','LOW','NONE','UNKNOWN']},'security_check_count':len(checks),'security_warnings':sum(r.get('status')=='WARN' for r in checks),'warning':'CVE counts represent imported findings, not an independent vulnerability scan; missing findings do not imply zero vulnerabilities.'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def table(data,cols):
    return '<table><thead><tr>'+''.join('<th>'+html.escape(c)+'</th>' for c in cols)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(c,'')))+'</td>' for c in cols)+'</tr>' for r in data)+'</tbody></table>'
css='body{font:14px system-ui,sans-serif;background:#101827;color:#e8edf6;margin:32px}h1,h2{color:#7ee1d3}table{border-collapse:collapse;width:100%;margin:15px 0 28px}th,td{border:1px solid #4b5c70;padding:8px;text-align:left;word-break:break-word}th{background:#23334a}.note{padding:12px;border:1px solid #e9a84b} .metrics{display:flex;gap:12px;flex-wrap:wrap}.metric{padding:14px;background:#22334a;border-radius:8px}'
htmlout='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Linux Farm Security Audit</title><style>'+css+'</style><h1>Linux Farm Audit — Controller Report</h1><p class="note">'+html.escape(manifest['warning'])+'</p><div class="metrics">'+''.join('<div class="metric"><strong>'+html.escape(s)+'</strong><p>'+str(counts[s])+'</p></div>' for s in ['CRITICAL','HIGH','MEDIUM','LOW','UNKNOWN'])+'</div><h2>Host status</h2>'+table(rows,['host','status']+sorted(set(rows[0])-{'host','status'}) if rows else ['host','status'])+'<h2>CVE findings (imported)</h2>'+table(cves,['host','cve','severity','cvss','package','source','status'])+'<h2>Security checks</h2>'+table(checks,['host','check','status','detail'])+'</html>'
(root/'index.html').write_text(htmlout)
print(json.dumps(manifest,indent=2))
