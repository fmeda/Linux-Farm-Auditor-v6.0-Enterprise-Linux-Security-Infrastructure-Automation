#!/usr/bin/env bash
set -euo pipefail
[[ $# -ge 1 && $# -le 5 ]] || { echo "Usage: $0 /mounted/share [inventory.ini] [advisories.json] [kev.json] [epss.csv]" >&2; exit 2; }
BASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$BASE_DIR"
SHARE=$1; INVENTORY=${2:-inventory.ini}; ADVISORIES=${3:-}; KEV=${4:-}; EPSS=${5:-}
INVENTORY="$(realpath -e -- "$INVENTORY")"
for input in "$ADVISORIES" "$KEV" "$EPSS"; do [[ -z "$input" || -f "$input" ]] || { echo "Missing input: $input" >&2; exit 2; }; done
[[ -z "$ADVISORIES" ]] || ADVISORIES="$(realpath -e -- "$ADVISORIES")"
[[ -z "$KEV" ]] || KEV="$(realpath -e -- "$KEV")"
[[ -z "$EPSS" ]] || EPSS="$(realpath -e -- "$EPSS")"
[[ "$SHARE" = /* && -d "$SHARE" && -w "$SHARE" ]] || { echo 'Invalid or unwritable absolute share' >&2; exit 2; }
mountpoint -q -- "$SHARE" || { echo 'Refusing to write: share is not a mount point' >&2; exit 2; }
command -v ansible-playbook >/dev/null || { echo 'ansible-playbook not found' >&2; exit 2; }
umask 077
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
DEST="$SHARE/$RUN_ID"
mkdir -m 700 -- "$DEST"
set +e
ansible-playbook -i "$INVENTORY" audit.yml -e "audit_share=$SHARE" -e "audit_run_id=$RUN_ID" > "$DEST/ansible.log" 2>&1
ANSIBLE_RC=$?
set -e
ARGS=(--root "$DEST" --inventory "$INVENTORY" --ansible-rc "$ANSIBLE_RC")
[[ -z "$ADVISORIES" ]] || ARGS+=(--advisories "$ADVISORIES")
set +e
python3 consolidate.py "${ARGS[@]}"
CONSOLIDATE_RC=$?
set -e
if [[ -n "$ADVISORIES" ]]; then
  CORR_ARGS=(--root "$DEST" --advisories "$ADVISORIES")
  [[ -z "$KEV" ]] || CORR_ARGS+=(--kev "$KEV")
  [[ -z "$EPSS" ]] || CORR_ARGS+=(--epss "$EPSS")
  set +e
  python3 correlate.py "${CORR_ARGS[@]}"
  CORRELATE_RC=$?
  set -e
fi
REPORT_RC=$(( CONSOLIDATE_RC + ${CORRELATE_RC:-0} ))
echo "Reports: $DEST"; echo "Ansible exit: $ANSIBLE_RC | Report exit: $REPORT_RC"
((ANSIBLE_RC == 0 && REPORT_RC == 0))
