#!/usr/bin/env python3
"""Read-only installed package inventory, no network and no package modifications."""
import csv,subprocess,sys
from pathlib import Path
out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True)
def cmd(argv):
 try:
  r=subprocess.run(argv,capture_output=True,text=True,timeout=90,check=False)
  return r.stdout if r.returncode==0 else None
 except (OSError,subprocess.TimeoutExpired):return None
rows=[];manager='UNSUPPORTED'
rpm=cmd(['rpm','-qa','--qf','%{NAME}\t%{EPOCH}\t%{VERSION}-%{RELEASE}\t%{ARCH}\n'])
if rpm is not None:
 manager='rpm'
 for line in rpm.splitlines():
  fields=line.split('\t')
  if len(fields)==4:
   name,epoch,ver,arch=fields; rows.append((name, (epoch+':' if epoch not in ('(none)','0','') else '')+ver,arch))
else:
 deb=cmd(['dpkg-query','-W','-f=${binary:Package}\t${Version}\t${Architecture}\n'])
 if deb is not None:
  manager='dpkg'
  for line in deb.splitlines():
   fields=line.split('\t')
   if len(fields)==3:rows.append(tuple(fields))
with out.open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['package','installed_version','arch','manager']);w.writerows((n,v,a,manager) for n,v,a in rows)
print(f'{manager}: {len(rows)} packages')
