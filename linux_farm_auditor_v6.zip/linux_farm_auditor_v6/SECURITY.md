# Security model and responsible operation

- **NIST CSF 2.0:** Govern/Identify/Protect/Detect: collect evidence, do not claim remediation.
- **CIS Controls v8:** inventory, secure configuration checks, vulnerability management, audit logging. These checks are partial mappings, **not a CIS benchmark certification**.
- **NIST SP 800-53:** CM-8, RA-5, AU-6, SI-2 as control-alignment references, not compliance attestations.
- **OWASP secure coding:** validate untrusted advisory input, HTML escape, restrict report permissions, avoid shell interpolation of remote input.
- **CVSS v3.x:** use published scores; **CISA KEV** and **EPSS** are prioritization context, not proof of compromise.
- **SLSA / supply chain:** pin dependencies in deployment, code review, provenance, and CI testing recommended; no formal SLSA level claimed.

## Trust boundaries
Ansible Controller is the only writer to NFS/SMB. Remote hosts only receive temporary collectors and return evidence via SSH. Use a least-privilege account, SSH host key checking, a dedicated share, restricted ACLs and retention controls. Package data and OS metadata are sensitive inventory. Imported feeds are snapshots, not live validation.

## CVE interpretation
The advisory must explicitly include `distro`, `distro_version`, `source`, `package`, `manager`, `fixed_version` and `cve`. Version comparison is **triage only**; distro backports and vendor errata can supersede naive version comparisons. `SCOPE_MISMATCH`, `UNVERIFIED_SCOPE` and `UNKNOWN_COMPARATOR` are not proof of vulnerability.
